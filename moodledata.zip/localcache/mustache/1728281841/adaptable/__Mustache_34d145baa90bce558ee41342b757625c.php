<?php

class __Mustache_34d145baa90bce558ee41342b757625c extends Mustache_Template
{
    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $buffer = '';

        $buffer .= $indent . '<li class="list-group-item course-listitem border-left-0 border-right-0 border-top-0 px-2 rounded-0">
';
        $buffer .= $indent . '    <div class="row">
';
        $buffer .= $indent . '        <div class="col-md-2 d-flex align-items-center">
';
        $buffer .= $indent . '            <div class="bg-pulse-grey card-img w-100" style="height: 1rem; width: 1rem;"></div>
';
        $buffer .= $indent . '        </div>
';
        $buffer .= $indent . '        <div class="col-md-10 d-flex flex-column">
';
        $buffer .= $indent . '            <div class="bg-pulse-grey w-50" style="height: 1rem; margin: 0.5rem 0"></div>
';
        $buffer .= $indent . '        </div>
';
        $buffer .= $indent . '    </div>
';
        $buffer .= $indent . '</li>
';

        return $buffer;
    }
}

<?php

class __Mustache_788a06c073b7987ae36cf349e880e5d0 extends Mustache_Template
{
    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $buffer = '';

        $buffer .= $indent . '</div>
';

        return $buffer;
    }
}

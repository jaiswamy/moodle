<?php
// ********** This file is generated DO NOT EDIT **********
$CFG->siteidentifier = 'y7EGOy7IbMGsYHag4P9fbK0MUqjY6T1ulms.hiideals.com';
$CFG->bootstraphash = '2fb273d888335fb2bb2f3f78906e2e9d';
// Only if the file is not stale and has not been defined.
if ($CFG->bootstraphash === hash_local_config_cache() && !defined('SYSCONTEXTID')) {
    define('SYSCONTEXTID', 1);
}
